import React from 'react';
import { Github, Linkedin, BookText, Terminal, Code2 } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center bg-black text-white">
      <div className="container mx-auto px-6 py-20">
        <div className="flex flex-col items-center text-center">
          <h1 className="text-5xl md:text-7xl font-bold mb-4 animate-slideUp">
            Backend Engineer
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-8 animate-slideUp animation-delay-200">
           High Enthusiast in Programming & Research | Problem Solver
          </p>
          <div className="flex space-x-6 mb-12 animate-slideUp animation-delay-400">
            <a href="https://github.com/Anower77" target="_blank" rel="noopener noreferrer" className="hover:text-gray-400 transition-colors">
              <Github size={28} />
            </a>
            <a href="https://www.linkedin.com/in/anower77/" target="_blank" rel="noopener noreferrer" className="hover:text-gray-400 transition-colors">
              <Linkedin size={28} />
            </a>
            <a href="https://hashnode.com/@Anower77" target="_blank" rel="noopener noreferrer" className="hover:text-gray-400 transition-colors">
              <BookText size={28} />
            </a>
            <a href="https://www.hackerrank.com/profile/anower77" target="_blank" rel="noopener noreferrer" className="hover:text-gray-400 transition-colors">
              <Terminal size={28} />
            </a>
            <a href="https://replit.com/@Anower77" target="_blank" rel="noopener noreferrer" className="hover:text-gray-400 transition-colors">
              <Code2 size={28} />
            </a>
          </div>
          <a 
            href="#contact" 
            className="bg-white hover:bg-gray-200 text-black px-8 py-3 rounded-full font-semibold transition-colors animate-slideUp animation-delay-600"
          >
            Get in Touch
          </a>
        </div>
      </div>
    </section>
  );
}