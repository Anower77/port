import React from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';

export default function ContactInfo() {
  return (
    <div>
      <h3 className="text-2xl font-semibold mb-6">Contact Information</h3>
      <div className="space-y-4">
        <div className="flex items-center">
          <Mail className="mr-4 text-teal-400" />
          <span>anowerhossain765562@gmail.com</span>
        </div>
        <div className="flex items-center">
          <Phone className="mr-4 text-teal-400" />
          <span>+8801623910549</span>
        </div>
        <div className="flex items-center">
          <MapPin className="mr-4 text-teal-400" />
          <span>Dhaka-Mirpur,23, Bangladesh</span>
        </div>
      </div>
    </div>
  );
}