import React from 'react';

export default function ContactForm() {
  return (
    <form className="space-y-6">
      <div>
        <label className="block text-sm font-medium mb-2">Name</label>
        <input 
          type="text" 
          className="w-full px-4 py-2 bg-black/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
          placeholder="Your name"
        />
      </div>
      <div>
        <label className="block text-sm font-medium mb-2">Email</label>
        <input 
          type="email" 
          className="w-full px-4 py-2 bg-black/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
          placeholder="Your email"
        />
      </div>
      <div>
        <label className="block text-sm font-medium mb-2">Message</label>
        <textarea 
          className="w-full px-4 py-2 bg-black/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 h-32"
          placeholder="Your message"
        ></textarea>
      </div>
      <button 
        type="submit"
        className="w-full bg-teal-600 hover:bg-teal-700 text-white py-3 rounded-lg font-semibold transition-colors"
      >
        Send Message
      </button>
    </form>
  );
}