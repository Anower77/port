import React from 'react';
import AwardCard from './AwardCard';

const awards = [
  {
    title: 'International Astronomy Astrophysics Competition',
    issuer: 'IAAC',
    date: 'Feb 2024',
    description: 'Bronze Distinction, placing in the top 35% globally in the final round.'
  },
  {
    title: 'International Mathematics Olympiad',
    issuer: 'IYMC',
    date: 'Nov 2023',
    description: 'Bronze Distinction, achieving top 30% global ranking with top 95% in final round.'
  },
  {
    title: 'ICPC Asia Dhaka Regional Contest',
    issuer: 'ACM-ICPC',
    date: 'Nov 2023',
    description: 'Team FCI-Programmer, achieved 189th position in the regional competition.'
  }
];

export default function Awards() {
  return (
    <section id="awards" className="py-20 bg-gradient-to-br from-black to-gray-900 text-white">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-12">Honors & Awards</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {awards.map((award, index) => (
            <AwardCard key={index} {...award} />
          ))}
        </div>
      </div>
    </section>
  );
}