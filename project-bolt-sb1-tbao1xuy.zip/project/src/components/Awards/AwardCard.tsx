import React from 'react';

interface AwardProps {
  title: string;
  issuer: string;
  date: string;
  description: string;
}

export default function AwardCard({ title, issuer, date, description }: AwardProps) {
  return (
    <div className="bg-gray-900 p-6 rounded-lg">
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-white mb-1">{issuer}</p>
      <p className="text-sm text-gray-400 mb-3">{date}</p>
      <p className="text-gray-300">{description}</p>
    </div>
  );
}