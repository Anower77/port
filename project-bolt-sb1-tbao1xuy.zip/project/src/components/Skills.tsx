import React from 'react';

const skills = [
  { 
    category: 'Programming Languages', 
    items: ['C++', 'C', 'Python']
  },
  { 
    category: 'Core Competencies', 
    items: ['Data Structures', 'Algorithms', 'Problem Solving', 'Competitive Programming']
  },
  { 
    category: 'Research & Development', 
    items: ['Technical Writing', 'Research Methodology', 'Documentation']
  },
  { 
    category: 'Tools & Technologies', 
    items: ['Git', 'VS Code', 'Linux', 'Docker']
  }
];

export default function Skills() {
  return (
    <section id="skills" className="py-20 bg-black">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center text-white mb-12">
          Skills & Expertise
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {skills.map((skillGroup) => (
            <div 
              key={skillGroup.category}
              className="bg-gray-900 p-6 rounded-lg hover:transform hover:scale-105 transition-transform duration-300"
            >
              <h3 className="text-xl font-semibold text-white mb-4">{skillGroup.category}</h3>
              <ul className="space-y-2">
                {skillGroup.items.map((skill) => (
                  <li key={skill} className="text-white flex items-center">
                    <span className="w-2 h-2 bg-white rounded-full mr-2"></span>
                    {skill}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}