import React from 'react';
import ProjectCard from './ProjectCard';

const projects = [
  {
    title: 'Job Portal',
    description: 'A comprehensive job portal platform with advanced search and application features',
    image: 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    github: 'https://github.com/Anower77/Job-Portal',
    live: 'https://job-portal-4uvu.onrender.com/'
  },
  {
    title: 'Polling REST API',
    description: 'RESTful API service for creating and managing polls with real-time results',
    image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    github: 'https://github.com/Anower77/POLLING-REST-API',
    live: 'https://polling-rest-api.onrender.com/'
  },
  {
    title: 'Library Management',
    description: 'Complete library management system with book tracking and user management',
    image: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    github: 'https://github.com/Anower77/Library-Management',
    live: '#'
  }
];

export default function Projects() {
  return (
    <section id="projects" className="py-20 bg-gradient-to-br from-gray-900 to-black text-white">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-12">Featured Projects</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <ProjectCard key={index} {...project} />
          ))}
        </div>
      </div>
    </section>
  );
}