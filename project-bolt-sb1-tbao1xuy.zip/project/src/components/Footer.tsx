import React from 'react';
import { Github, Linkedin, BookText, Terminal } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black text-white py-12">
      <div className="container mx-auto px-6">
        <div className="flex flex-col items-center">
          <div className="flex space-x-6 mb-8">
            <a href="https://github.com/Anower77" target="_blank" rel="noopener noreferrer" className="hover:text-purple-400 transition-colors">
              <Github size={24} />
            </a>
            <a href="https://www.linkedin.com/in/anower77/" target="_blank" rel="noopener noreferrer" className="hover:text-purple-400 transition-colors">
              <Linkedin size={24} />
            </a>
            <a href="https://hashnode.com/@Anower77" target="_blank" rel="noopener noreferrer" className="hover:text-purple-400 transition-colors">
              <BookText size={24} />
            </a>
            <a href="https://www.hackerrank.com/profile/anower77" target="_blank" rel="noopener noreferrer" className="hover:text-purple-400 transition-colors">
              <Terminal size={24} />
            </a>
          </div>
          <p className="text-center text-gray-400">
            © {new Date().getFullYear()} Anower Hossain. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}