import React from 'react';

export default function About() {
  return (
    <section id="about" className="py-20 bg-black text-white">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-12">About Me</h2>
        <div className="max-w-3xl mx-auto">
          <p className="text-lg leading-relaxed mb-6">
            I have been working as a programmer for several years, with extensive experience in languages like C, C++, and Python, 
            along with a strong foundation in Algorithms and Data Structures. I am passionate about problem-solving and enjoy finding 
            creative solutions to complex challenges.
          </p>
          <p className="text-lg leading-relaxed mb-6">
            Beyond technical skills, I excel at explaining complex concepts in simple terms. I stay updated on the latest programming 
            trends and continuously seek to improve my knowledge and expertise. With a focus on backend engineering, I combine my 
            problem-solving abilities with technical expertise to create efficient and scalable solutions.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
            <div className="bg-gray-900 p-6 rounded-lg">
              <h3 className="text-xl font-semibold mb-4">Experience</h3>
              <ul className="space-y-4">
                <li>
                  <h4 className="font-medium">Exercism (Problem Solving)</h4>
                  <p className="text-gray-400">Aug 2019 - Sep 2023</p>
                  <p className="text-sm text-gray-400">C++, Problem Solving</p>
                </li>
                <li>
                  <h4 className="font-medium">Python Essential Course</h4>
                  <p className="text-gray-400">Cisco Networking Academy</p>
                  <p className="text-sm text-gray-400">May 2021 - Mar 2022</p>
                </li>
              </ul>
            </div>
            <div className="bg-gray-900 p-6 rounded-lg">
              <h3 className="text-xl font-semibold mb-4">Achievements</h3>
              <ul className="space-y-4">
                <li>
                  <h4 className="font-medium">ICPC Dhaka Regional Site 2023</h4>
                  <p className="text-gray-400">International Collegiate Programming Contest</p>
                </li>
                <li>
                  <h4 className="font-medium">International Astronomy Competition</h4>
                  <p className="text-gray-400">Bronze Distinction (Top 35% Globally)</p>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}